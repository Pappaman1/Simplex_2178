#include "MyOctantExample.h"
using namespace Simplex;


